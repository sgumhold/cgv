op_version_set = 1
import __torch__.torch.nn.modules.conv
import __torch__.torch.nn.modules.conv.___torch_mangle_0
import __torch__.torch.nn.modules.dropout
import __torch__.torch.nn.modules.linear
import __torch__.torch.nn.modules.linear.___torch_mangle_1
class Net(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  conv2_drop : __torch__.torch.nn.modules.dropout.Dropout2d
  fc1 : __torch__.torch.nn.modules.linear.Linear
  fc2 : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  def forward(self: __torch__.network.Net,
    input: Tensor) -> Tensor:
    _0 = self.conv1
    weight = _0.weight
    _1 = _0.bias
    _2 = self.conv2
    weight0 = _2.weight
    _3 = _2.bias
    _4 = self.fc1
    weight1 = _4.weight
    bias = _4.bias
    _5 = self.fc2
    weight2 = _5.weight
    bias0 = _5.bias
    input0 = torch._convolution(input, weight, _1, [1, 1], [0, 0], [1, 1], False, [0, 0], 1, False, False, True)
    input1 = torch.max_pool2d(input0, [2, 2], annotate(List[int], []), [0, 0], [1, 1], False)
    input2 = torch.relu(input1)
    input3 = torch._convolution(input2, weight0, _3, [1, 1], [0, 0], [1, 1], False, [0, 0], 1, False, False, True)
    input4 = torch.feature_dropout(input3, 0.5, False)
    input5 = torch.max_pool2d(input4, [2, 2], annotate(List[int], []), [0, 0], [1, 1], False)
    x = torch.relu(input5)
    input6 = torch.view(x, [-1, 320])
    input7 = torch.addmm(bias, input6, torch.t(weight1), beta=1, alpha=1)
    input8 = torch.relu(input7)
    input9 = torch.dropout(input8, 0.5, False)
    input10 = torch.addmm(bias0, input9, torch.t(weight2), beta=1, alpha=1)
    return torch.log_softmax(input10, 1, None)
