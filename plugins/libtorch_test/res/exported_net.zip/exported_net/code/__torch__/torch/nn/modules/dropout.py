op_version_set = 1
class Dropout2d(Module):
  __parameters__ = []
  training : bool
