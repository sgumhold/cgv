op_version_set = 1
class Conv2d(Module):
  __parameters__ = ["weight", "bias", ]
  training : bool
  weight : Tensor
  bias : Tensor
