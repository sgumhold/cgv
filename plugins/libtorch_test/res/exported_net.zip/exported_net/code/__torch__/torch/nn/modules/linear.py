op_version_set = 1
class Linear(Module):
  __parameters__ = ["weight", "bias", ]
  training : bool
  weight : Tensor
  bias : Tensor
